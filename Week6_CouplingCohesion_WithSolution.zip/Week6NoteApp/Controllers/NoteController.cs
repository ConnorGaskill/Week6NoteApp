public class NoteController
{
    private NoteService _service = new NoteService();

    public string ShowNotes()
    {
        return _service.FormatNotesForPrint();
    }
}