using System;
using System.Collections.Generic;

public class NoteService
{
    private List<Note> _notes = new();

    public void AddNote(string text)
    {
        var note = new Note { Text = text, CreatedAt = DateTime.Now };
        _notes.Add(note);
        Console.WriteLine($"[LOG] Note added: {text}");
    }

    public List<Note> GetAllNotes()
    {
        return _notes;
    }

    public string FormatNotesForPrint()
    {
        return string.Join("\n", _notes.Select(n => $"{n.CreatedAt}: {n.Text}"));
    }
}