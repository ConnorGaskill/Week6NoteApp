using System.Collections.Generic;

public interface INoteFormatter
{
    string Format(List<Note> notes);
}